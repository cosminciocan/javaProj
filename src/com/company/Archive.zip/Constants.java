package com.company;

/**
 * Created by cosminciocan on 19/07/2017.
 */
public class Constants {

    public static final String USERNAME = "intern";
    public static final String PASS = "pass";

    public static final int MAX_NUMBERS_OF_TRY = 3;
}
