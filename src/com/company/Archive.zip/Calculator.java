package com.company;

public class Calculator {

    public static int sum(int a, int b){
        return (a+b);
    }

}
